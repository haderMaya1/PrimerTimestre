/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taller_ciclos;

/**
 *
 * @author Jader
 */
public class ej_26 {
    public static void main(String[] args) {
        
          for (int i = 1; i < 8; i++) 
       { 
            for (int j = 0; j < 4; j++) 
            {
                System.out.print("     ");
                System.out.print(i+j);
            }
            System.out.println("  ");
        }
        
    }
}
