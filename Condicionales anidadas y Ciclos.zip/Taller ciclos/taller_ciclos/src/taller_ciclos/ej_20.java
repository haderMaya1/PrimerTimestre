/*
20. Mostrar los números del 0-9 con haga mientras
*/
package taller_ciclos;

public class ej_20 {
    public static void main(String[] args) {
        
        int n=0;
        do 
        {
           n++; 
           System.out.println("# " + n); 
        } while (n<9);
        
    }
}
