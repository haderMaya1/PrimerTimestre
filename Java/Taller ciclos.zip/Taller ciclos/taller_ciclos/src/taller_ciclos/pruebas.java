/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taller_ciclos;

import java.util.Scanner;

/**
 *
 * @author Jader
 */
public class pruebas {
    public static void main(String[] args) {
        Scanner s = new Scanner (System.in);
        String c="Hola";
        int n = 0;
        do 
        {
           n++;
           System.out.println(c);
        } while (n<5); 
            
    }
}
