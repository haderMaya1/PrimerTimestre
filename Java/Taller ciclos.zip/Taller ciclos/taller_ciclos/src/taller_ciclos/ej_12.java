/*
12. Imprimir por pantalla 5 líneas de caracteres
*****
*****
*****
*****
*****
*/
package taller_ciclos;



public class ej_12 {
    public static void main(String[] args) {
        
        System.out.println("¡Hola amigo!");
        System.out.println("Estoy programando");
        System.out.println("En Java");
        System.out.println("Intentalo tu tambien");
        System.out.println("¡Es muy divertido!");
    }
}
